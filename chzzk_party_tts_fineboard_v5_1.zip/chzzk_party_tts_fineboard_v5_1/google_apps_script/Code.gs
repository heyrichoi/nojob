const FIRST_PLAYER_ROW = 2;
const CONFIG_AMOUNT_CELL = 'D2';
const CONFIG_UNIT_CELL = 'E2';

/**
 * 최초 1회 Apps Script 편집기에서 직접 실행합니다.
 * 현재 스프레드시트/현재 탭을 API 백엔드로 등록합니다.
 */
function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getActiveSheet();
  if (!ss || !sheet) throw new Error('스프레드시트에 연결된 Apps Script에서 실행해 주세요.');

  const props = PropertiesService.getScriptProperties();
  props.setProperty('SPREADSHEET_ID', ss.getId());
  props.setProperty('SHEET_GID', String(sheet.getSheetId()));

  SpreadsheetApp.getUi().alert(
    '설정 완료',
    'A열 닉네임 / B열 횟수 / D2 1회당 금액 / E2 단위\n\n이제 웹 앱으로 배포해 주세요.',
    SpreadsheetApp.getUi().ButtonSet.OK
  );
}

function doGet(e) {
  try {
    return json_({ ok: true, data: getAppData_() });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const action = String(body.action || '');
    let data;

    if (action === 'adjust') data = adjustCount_(body.row, body.delta);
    else if (action === 'set') data = setCount_(body.row, body.count);
    else if (action === 'reset') data = resetAll_();
    else if (action === 'config') data = saveConfig_(body.perCount, body.unit);
    else throw new Error('알 수 없는 action 입니다.');

    return json_({ ok: true, data });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}

function getAppData_() {
  const sheet = getBackendSheet_();
  const lastRow = Math.max(sheet.getLastRow(), FIRST_PLAYER_ROW);
  const numRows = Math.max(0, lastRow - FIRST_PLAYER_ROW + 1);
  const values = numRows > 0
    ? sheet.getRange(FIRST_PLAYER_ROW, 1, numRows, 2).getDisplayValues()
    : [];

  const perCount = Math.max(0, Number(sheet.getRange(CONFIG_AMOUNT_CELL).getValue()) || 0);
  const unit = String(sheet.getRange(CONFIG_UNIT_CELL).getDisplayValue() || '').trim();
  const players = [];

  values.forEach((row, i) => {
    const name = String(row[0] || '').trim();
    if (!name) return;
    const raw = String(row[1] || '0').replace(/[^0-9-]/g, '');
    const count = Math.max(0, parseInt(raw, 10) || 0);
    players.push({
      row: FIRST_PLAYER_ROW + i,
      name,
      count,
      amount: count * perCount
    });
  });

  const totalCount = players.reduce((sum, p) => sum + p.count, 0);
  return {
    title: '노잡 무공 벌금',
    players,
    perCount,
    unit,
    totalCount,
    totalAmount: totalCount * perCount,
    serverTime: Date.now()
  };
}

function adjustCount_(row, delta) {
  row = Number(row);
  delta = Number(delta);
  if (!Number.isInteger(row) || row < FIRST_PLAYER_ROW) throw new Error('잘못된 행 번호입니다.');
  if (!Number.isFinite(delta) || Math.abs(delta) > 1000) throw new Error('잘못된 변경값입니다.');

  const lock = LockService.getScriptLock();
  lock.waitLock(5000);
  try {
    const sheet = getBackendSheet_();
    const name = String(sheet.getRange(row, 1).getDisplayValue() || '').trim();
    if (!name) throw new Error('해당 행에 닉네임이 없습니다.');
    const cell = sheet.getRange(row, 2);
    const current = Math.max(0, Number(cell.getValue()) || 0);
    cell.setValue(Math.max(0, current + delta));
    SpreadsheetApp.flush();
    return getAppData_();
  } finally {
    lock.releaseLock();
  }
}

function setCount_(row, count) {
  row = Number(row);
  count = Math.max(0, Math.floor(Number(count) || 0));
  if (!Number.isInteger(row) || row < FIRST_PLAYER_ROW) throw new Error('잘못된 행 번호입니다.');

  const lock = LockService.getScriptLock();
  lock.waitLock(5000);
  try {
    const sheet = getBackendSheet_();
    const name = String(sheet.getRange(row, 1).getDisplayValue() || '').trim();
    if (!name) throw new Error('해당 행에 닉네임이 없습니다.');
    sheet.getRange(row, 2).setValue(count);
    SpreadsheetApp.flush();
    return getAppData_();
  } finally {
    lock.releaseLock();
  }
}

function resetAll_() {
  const lock = LockService.getScriptLock();
  lock.waitLock(5000);
  try {
    const sheet = getBackendSheet_();
    const lastRow = Math.max(sheet.getLastRow(), FIRST_PLAYER_ROW);
    const numRows = Math.max(0, lastRow - FIRST_PLAYER_ROW + 1);
    if (numRows > 0) {
      const names = sheet.getRange(FIRST_PLAYER_ROW, 1, numRows, 1).getDisplayValues();
      sheet.getRange(FIRST_PLAYER_ROW, 2, numRows, 1)
        .setValues(names.map(r => [String(r[0] || '').trim() ? 0 : '']));
    }
    SpreadsheetApp.flush();
    return getAppData_();
  } finally {
    lock.releaseLock();
  }
}

function saveConfig_(perCount, unit) {
  perCount = Math.max(0, Math.floor(Number(perCount) || 0));
  unit = String(unit || '').trim().slice(0, 20);
  const sheet = getBackendSheet_();
  sheet.getRange(CONFIG_AMOUNT_CELL).setValue(perCount);
  sheet.getRange(CONFIG_UNIT_CELL).setValue(unit);
  SpreadsheetApp.flush();
  return getAppData_();
}

function getBackendSheet_() {
  const props = PropertiesService.getScriptProperties();
  const spreadsheetId = props.getProperty('SPREADSHEET_ID');
  const sheetGid = Number(props.getProperty('SHEET_GID'));
  if (!spreadsheetId || !Number.isFinite(sheetGid)) throw new Error('setup()을 먼저 실행해 주세요.');

  const ss = SpreadsheetApp.openById(spreadsheetId);
  const sheet = ss.getSheets().find(s => s.getSheetId() === sheetGid);
  if (!sheet) throw new Error('등록된 시트를 찾지 못했습니다. setup()을 다시 실행해 주세요.');
  return sheet;
}

function json_(value) {
  return ContentService
    .createTextOutput(JSON.stringify(value))
    .setMimeType(ContentService.MimeType.JSON);
}
